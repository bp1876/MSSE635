/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.Inventory;

/**
 * @author Brenda Palmer
 *
 */
public class InventoryTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.Inventory#toString()}.
	 */
	@Test
	public void testToString() {
		
		Inventory inventory = new Inventory();
		equals(inventory.bikeRecordIDs);
	}

}
