/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.ManagerAccount;

/**
 * @author Brenda Palmer
 *
 */
public class ManagerAccountTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.ManagerAccount#toString()}.
	 */
	@Test
	public void testToString() {
		
		ManagerAccount managerAccount = new ManagerAccount();
		equals(managerAccount.accountID);
	}

}
