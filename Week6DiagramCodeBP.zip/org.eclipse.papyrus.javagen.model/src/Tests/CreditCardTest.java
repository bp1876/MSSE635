package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.CreditCard;


/**
 * @author Brenda Palmer
 *
 */

public class CreditCardTest {
	
	/**
	 * @throws java.lang.Exception
	 */

	@Before
	public void setUp() throws Exception {
	}
	
	/**
	 * Test method for {@link model.ClassDiagram.CreditCard#toString()}.
	 */

	@Test
	public void testToString() {
		
		CreditCard creditCard = new CreditCard();
		equals(creditCard.accountID);
	}

}
