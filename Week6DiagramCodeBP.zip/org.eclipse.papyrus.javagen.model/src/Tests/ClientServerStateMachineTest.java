/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.StateMachineDiagram.ClientServerStateMachine;

/**
 * @author Brenda Palmer
 *
 */
public class ClientServerStateMachineTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.StateMachineDiagram.ClientServerStateMachine#toString()}.
	 */
	@Test
	public void testToString() {
		ClientServerStateMachine cssm = new ClientServerStateMachine();
		equals(cssm.toString());
	}

}
