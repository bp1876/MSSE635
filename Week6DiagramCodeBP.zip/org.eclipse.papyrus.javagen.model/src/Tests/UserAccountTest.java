/**
 * 
 */
package Tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.UserAccount;

/**
 * @author Brenda Palmer
 *
 */
public class UserAccountTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.UserAccount#toString()}.
	 */
	@Test
	public void testToString() {
		
		UserAccount userAccount = new UserAccount();
		equals(userAccount.name);
	}

}
