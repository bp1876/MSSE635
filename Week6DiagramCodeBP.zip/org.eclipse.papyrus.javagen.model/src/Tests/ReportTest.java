/**
 * 
 */
package Tests;


import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.Report;

/**
 * @author Brenda Palmer
 *
 */
public class ReportTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.Report#toString()}.
	 */
	@Test
	public void testToString() {

		Report report = new Report();
		equals(report.reportNumber);
	}

}
