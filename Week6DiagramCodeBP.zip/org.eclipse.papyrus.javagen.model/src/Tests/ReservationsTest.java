/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.Reservations;

/**
 * @author Brenda Palmer
 *
 */
public class ReservationsTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.Reservations#toString()}.
	 */
	@Test
	public void testToString() {
		
		Reservations reservations = new Reservations();
		equals(reservations.bikeIDs);
	}

}
