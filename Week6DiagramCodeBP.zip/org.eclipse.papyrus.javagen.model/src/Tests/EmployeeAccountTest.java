/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.EmployeeAccount;

/**
 * @author Brenda Palmer
 *
 */
public class EmployeeAccountTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.EmployeeAccount#toString()}.
	 */
	@Test
	public void testToString() {
		
		EmployeeAccount employeeAccount = new EmployeeAccount();
		equals(employeeAccount.accountID);
	}

}
