/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.BikeHistory;

/**
 * @author Brenda Palmer
 *
 */
public class BikeHistoryTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.BikeHistory#toString()}.
	 */
	@Test
	public void testToString() {
		BikeHistory bikeHistory = new BikeHistory();
		equals(bikeHistory.bikeID);
	}

}
