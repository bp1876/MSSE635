package Tests;



import org.junit.Before;

import org.junit.Test;

import model.ClassDiagram.Customer;

/**
 * @author Brenda Palmer
 *
 */

public class CustomerTest {
	
	/**
	 * @throws java.lang.Exception
	 */

	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.Customer#toString()}.
	 */
	@Test
	public void testToString() {
		
		Customer customer = new Customer();
		equals(customer.accountID);
	}

}
