/**
 * 
 */
package Tests;



import org.junit.Before;
import org.junit.Test;

import model.ClassDiagram.BikeRecords;

/**
 * @author Brenda Palmer
 *
 */
public class BikeRecordsTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test method for {@link model.ClassDiagram.BikeRecords#toString()}.
	 */
	@Test
	public void testToString() {
		
		BikeRecords bikeRecords = new BikeRecords();
		equals(bikeRecords.bikeID);
	}

}
